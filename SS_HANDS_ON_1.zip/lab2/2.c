#include<stdio.h>
#include<fcntl.h>
int main(){
  for(;;);
  return 1;
}
